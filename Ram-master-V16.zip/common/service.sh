#!/system/bin/sh
MODDIR=${0%/*}

# Execute script by tytydraco and his project ktweak, thanks! 
write() {
	# Bail out if file does not exist
	[[ ! -f "$1" ]] && return 1
	
	# Make file writable in case it is not already
	chmod +w "$1" 2> /dev/null

	# Write the new value and bail if there's an error
	if ! echo "$2" > "$1" 2> /dev/null
	then
		echo "Failed: $1 → $2"
		return 1
	fi
}

sleep 30

# Add ZRAM FOR ZRAM0 BY Hải
swapoff /dev/block/zram0
echo "1" > /sys/block/zram0/reset
echo "4294967296" > /sys/block/zram0/disksize
echo "4096M" > /sys/block/zram0/mem_limit
echo "8" > /sys/block/zram0/max_comp_streams
mkswap /dev/block/zram0
swapon /dev/block/zram0
echo "100" > /proc/sys/vm/swappiness
echo "10" > /proc/sys/vm/dirty_background_ratio
echo "80" > /proc/sys/vm/vfs_cache_pressure
echo "1" > /proc/sys/vm/overcommit_memory
echo "500" > /proc/sys/vm/dirty_writeback_centisecs
echo "0" > /proc/sys/vm/oom_kill_allocating_task
echo "0" > /proc/sys/vm/block_dump
echo "1" > /sys/module/lowmemorykiller/parameters/oom_reaper
chmod 666 /sys/module/lowmemorykiller/parameters/minfree
chown root /sys/module/lowmemorykiller/parameters/minfree
echo "14535,29070,43605,58112,72675,87210" > /sys/module/lowmemorykiller/parameters/minfree
chmod 444 /sys/module/lowmemorykiller/parameters/minfree

# Vm Tinh chỉnh 2.0
echo "100" > /proc/sys/vm/swap_ratio
echo "0" > /proc/sys/vm/swap_ratio_enable
echo "3000" > /proc/sys/vm/dirty_expire_centisecs
echo "0" > /proc/sys/vm/laptop_mode
echo "0" > /proc/sys/vm/page-cluster
echo "10" > /proc/sys/vm/stat_interval
echo "32" > /proc/sys/vm/watermark_scale_factor
echo "8192" > /proc/sys/vm/min_free_kbytes
echo "29615" > /proc/sys/vm/extra_free_kbytes
echo "750" > /proc/sys/vm/extfrag_threshold
echo "30" > /proc/sys/vm/dirty_ratio
echo "0" > /sys/module/lowmemorykiller/parameters/enable_adaptive_lmk
echo "0" > /sys/module/lowmemorykiller/parameters/enable_lmk
echo "0" > /sys/module/lowmemorykiller/parameters/debug_level
rm /data/system/perfd/default_values

# OOM cài đặt
echo "0" > /proc/sys/vm/oom_dump_tasks
echo "0" > /proc/sys/vm/panic_on_oom
echo "0" > /proc/sys/vm/reap_mem_on_sigkill

# Commit ram
echo "50" > /proc/sys/vm/overcommit_ratio
echo "0" > /proc/sys/vm/compact_unevictable_allowed
echo "1" > /proc/sys/vm/compact_memory

#Tối ưu hóa trình quản lý hoạt động
# Activity manager
if [ $(getprop ro.build.version.sdk) -gt 28 ]; then
  device_config set_sync_disabled_for_tests persistent
  device_config put activity_manager max_phantom_processes 2147483647
  device_config put activity_manager max_cached_processes 64
  device_config put activity_manager max_empty_time_millis 43200000
  settings put global settings_enable_monitor_phantom_procs false
else
  settings put global activity_manager_constants max_cached_processes=64
fi

#IO , noop cho thời lượng pin tốt nhất
for queue in /sys/block/*/queue
do
     echo "cfq" > $queue/scheduler
	 echo "0" > $queue/add_random
	 echo "0" > $queue/iostats
	 echo "1" > $queue/rq_affinity
	 echo "0" > $queue/rotational
	 echo "128" > $queue/read_ahead_kb
	 echo "128" > $queue/nr_requests
	 echo "0" > $queue/iosched/slice_idle
	 echo "0" > $queue/iosched/slice_idle_us
     echo "8" > $queue/iosched/group_idle
     echo "8000" > $queue/iosched/group_idle_us
     echo "1" > $queue/iosched/low_latency
     echo "100" > $queue/iosched/target_latency
     echo "100000" > $queue/iosched/target_latency_us
done

# Blkio by kernel bloox và gpt chat
if [ -d /dev/blkio ]; then
  echo "1000" > /dev/blkio/blkio.weight
  echo "200" > /dev/blkio/background/blkio.weight
  echo "2000" > /dev/blkio/blkio.group_idle
  echo "0" > /dev/blkio/background/blkio.group_idle
fi

# Entropy : thủa nghiệm sự ổn định và nó tạo ra nhất quán không 
echo "64" > /proc/sys/kernel/random/read_wakeup_threshold
echo "512" > /proc/sys/kernel/random/write_wakeup_threshold

# Zram đọc
echo "0" > /sys/fs/f2fs_dev/mmcblk0p79/iostat_enable
#echo "512" > /sys/block/zram0/queue/read_ahead_kb

# Tắt kết xuất ram
echo "0" > /sys/module/subsystem_restart/parameters/enable_ramdumps
echo "0" > /sys/module/subsystem_restart/parameters/enable_mini_ramdumps

sleep 20

# kết thúc
su -lp 2000 -c "cmd notification post -S bigtext -t 'Tối ưu hoàn tất' 'Tag' 'Nếu hay hãy ủng hộ cho tác giả nhé !!'"

# xoá ram
sync
echo "3" > /proc/sys/vm/drop_caches
am kill-all

exit 0