SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=false
LATESTARTSERVICE=true

print_modname() {
  sleep 1
  ui_print " Bởi : Anhsnguyetj  "
  sleep 1
  ui_print " đợi tí "
  sleep 1
  ui_print " đang bắt đầu cài đặt "
  sleep 1
  ui_print " quá trình cài đặt thành công "
  sleep 1
  ui_print " reboot để có thể sử dụng "
}

on_install() {
 unzip -o "$ZIPFILE" system/* -d $MODPATH >&2
}

set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
}